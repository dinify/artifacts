A watcher for CLDR SurveyTool.

Quite under documented.

copy config/SOMEHOST.json to config/localhost.json  where localhost is your hostname.

If node is installed, 'make' should fire up the server.

http://127.0.0.1:3000 should show you the watcher.



